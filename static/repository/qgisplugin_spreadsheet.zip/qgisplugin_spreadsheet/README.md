# qgisplugin_spreadsheet
QGIS Plugin for loading spreadsheet data
